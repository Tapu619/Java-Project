import bin.Client.ClientHome;
import bin.Client.ClientPay;
import bin.Client.ClientRegistration;
import bin.Client.GarageAvl;
import bin.GarageOwner.History;
import bin.GarageOwner.OwnerHome;
import bin.GarageOwner.OwnerRegistration;
import bin.GarageOwner.OwnerWithdraw;
import bin.Login.*;

public class Start {

  public static void main(String[] args) {
    //    Login Test = new Login();
    RegistrationType Tes = new RegistrationType();
    //    ClientRegistration Test = new ClientRegistration();
    // ClientHome Test = new ClientHome();
    //   ClientPay p = new ClientPay();

    //    OwnerRegistration Test = new OwnerRegistration();
    //OwnerHome Test = new OwnerHome();
    //    OwnerWithdraw Test = new OwnerWithdraw();
    //    History Test = new History();
  }
}
